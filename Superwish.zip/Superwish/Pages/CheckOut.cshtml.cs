using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Superwish_FSD04_AppDevII_ASP.NET_Project.Pages
{
    public class CheckOutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
