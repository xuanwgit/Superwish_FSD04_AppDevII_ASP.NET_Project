using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Superwish_FSD04_AppDevII_ASP.NET_Project.Models;
using Microsoft.EntityFrameworkCore;

namespace Superwish_FSD04_AppDevII_ASP.NET_Project.Data
{
    public static class ModelBuilderExtensions
    {
        public static ModelBuilder Seed(this ModelBuilder modelBuilder){
            modelBuilder.Entity<Item>().HasData(
                new Item
                {
                    Id = 1,
                    Name = "0c74d505a3634fa0486f1421afee1a22",
                    Description = "Alian Dinosaur War Robot",
                    Price = 8.99m,
                    QuantityRemaining = 3,
                    ImageUrl = "0c74d505a3634fa0486f1421afee1a22.jpg"
                },
                new Item
                {
                    Id = 2,
                    Name = "1babe994c9c741912bba22de13170e85",
                    Description = "Alian Dinosaur War Robot",
                    Price = 9.99m,
                    QuantityRemaining = 5,
                    ImageUrl = "1babe994c9c741912bba22de13170e85.jpg"
                },
                new Item
                {
                    Id = 3,
                    Name = "04ecb0d7d67486c4f0757f4aba42f8dd",
                    Description = "Alian Dinosaur War Robot",
                    Price = 5.99m,
                    QuantityRemaining = 3,
                    ImageUrl = "04ecb0d7d67486c4f0757f4aba42f8dd.jpg"
                },
                new Item
                {
                    Id = 4,
                    Name = "4c61f6daffc7467b2bb7bd786db1a1cb",
                    Description = "Alian Dinosaur War Robot",
                    Price = 1.49m,
                    QuantityRemaining = 7,
                    ImageUrl = "4c61f6daffc7467b2bb7bd786db1a1cb.jpg"
                },
                new Item
                {
                    Id = 5,
                    Name = "7da0762780fe821e6e0fc7f1803ac0cf",
                    Description = "Alian Dinosaur War Robot",
                    Price = 5.99m,
                    QuantityRemaining = 8,
                    ImageUrl = "7da0762780fe821e6e0fc7f1803ac0cf.jpg"
                },
                new Item
                {
                    Id = 6,
                    Name = "8da11f518016fde955370b5b76fb44a5",
                    Description = "Alian Dinosaur War Robot",
                    Price = 8.99m,
                    QuantityRemaining = 3,
                    ImageUrl = "8da11f518016fde955370b5b76fb44a5.jpg"
                }
            );
            return modelBuilder;
        }
    }
}